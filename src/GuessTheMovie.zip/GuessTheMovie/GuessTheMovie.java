package GuessTheMovie;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class GuessTheMovie {

    public void startPlaying() {
        boolean winFlag = false;
        int noOfMovie = 0;
        List<String> movies = new ArrayList<>();
        List<Character> wrongGuesses = new ArrayList<>();
        File movieList = new File("movieList.txt");
        Scanner fileScanner = null;
        try {
            fileScanner = new Scanner(movieList);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        while (fileScanner.hasNextLine()) {
            movies.add(fileScanner.nextLine());
            noOfMovie = noOfMovie + 1;

        }
        Random random = new Random();
        int randomMovieNo = random.nextInt(noOfMovie);
        String randomMovie = movies.get(randomMovieNo);
        String randomMovieInUnderscore = randomMovie.replaceAll("[a-zA-Z]", "_");
        System.out.println(randomMovie);

        for (int wrongGuess = 0; wrongGuess < 10; wrongGuess++) {
            System.out.println("You Are Guessing :" + randomMovieInUnderscore);
            System.out.println("You have Guessed (" + wrongGuess + ") Wrong Letters:" + wrongGuesses);
            System.out.print("Guess a Letter :");

            Scanner userScanner = new Scanner(System.in);
            char guessedLetter = userScanner.next().charAt(0);
            StringBuilder newRandomMovieInUnderscore = new StringBuilder(randomMovieInUnderscore);
            if (randomMovie.indexOf(guessedLetter) == -1) {
                wrongGuesses.add(guessedLetter);
            }
            else {

                for (int i = 0; i < randomMovie.length(); i++) {
                    if (randomMovie.charAt(i) == guessedLetter) {
                        newRandomMovieInUnderscore.setCharAt(i, guessedLetter);
                    }
                }
                wrongGuess--;
            }
            System.out.println(newRandomMovieInUnderscore);
            randomMovieInUnderscore = newRandomMovieInUnderscore.toString();
            if (randomMovieInUnderscore.indexOf('_') == -1) {
                winFlag = true;
                break;
            }
        }
        if (winFlag) {
            System.out.println("******** YOU WIN *********");
        } else {
            System.out.println("******** YOU LOSE *********");
        }
    }


}
