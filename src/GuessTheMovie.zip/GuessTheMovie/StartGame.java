package GuessTheMovie;

public class StartGame {
    public static void main(String[] args) {
        GuessTheMovie guessTheMovie = new GuessTheMovie();
        guessTheMovie.startPlaying();
    }
}
